 <!-- Start your project here-->
 <main >
      <div class="row wow bounceInLeft" data-wow-duration="2s" data-wow-offset="10"  data-wow-iteration="1">
    <div class="bg-image hover-overlay hover-zoom hover-shadow ripple col-4">
      <img src="view/img/vios.jpg" class="w-75" />
      <p>- Loại xe: Sedan<br>
        - Đời xe: 2020<br>
        - Màu xe: Trắng<br>
        - Hộp số: Số sàn<br>
        - Giá thuê xe: 600.000đ</p>
      <a href="#!">
        <div class="mask" style="background-color: rgba(137, 182, 197, 0.2)">
        <img src="view/img/xe-hover1.png" class="w-100" alt="">
        
      </div>
      
      </a>
    </div>
    <div class="bg-image hover-overlay hover-zoom hover-shadow ripple col-4">
      <img src="view/img/altis.jpg" class="w-75" />
      <p>- Loại xe: Sedan<br>
        - Đời xe: 2020<br>
        - Màu xe: Trắng<br>
        - Hộp số: Số sàn<br>
        - Giá thuê xe: 600.000đ</p>
      <a href="#!">
        <div class="mask" style="background-color: rgba(137, 182, 197, 0.2)">
        <img src="view/img/xe-hover1.png" class="w-100" alt="">
        
      </div>
      
      </a>
    </div>
    <div class="bg-image hover-overlay hover-zoom hover-shadow ripple col-4">
      <img src="view/img/mazda3.jpg" class="w-75" />
      <p>- Loại xe: Sedan<br>
        - Đời xe: 2020<br>
        - Màu xe: Trắng<br>
        - Hộp số: Số sàn<br>
        - Giá thuê xe: 600.000đ</p>
      <a href="#!">
        <div class="mask" style="background-color: rgba(137, 182, 197, 0.2)">
        <img src="view/img/xe-hover1.png" class="w-100" alt="">
        
      </div>
      
      </a>
    </div>   

    </div>
    <div class="row wow bounceInRight" data-wow-duration="2s" data-wow-offset="10"  data-wow-iteration="1">
      <div class="bg-image hover-overlay hover-zoom hover-shadow ripple col-4">
        <img src="view/img/fadil.png" class="w-75" />
        <p>- Loại xe: Hatchback<br>
          - Đời xe: 2020<br>
          - Màu xe: Trắng<br>
          - Hộp số: Số sàn<br>
          - Giá thuê xe: 600.000đ</p>
        <a href="#!">
          <div class="mask" style="background-color: rgba(137, 182, 197, 0.2)">
          <img src="view/img/xe-hover1.png" class="w-100" alt="">
          
        </div>
        
        </a>
      </div>
      <div class="bg-image hover-overlay hover-zoom hover-shadow ripple col-4">
        <img src="view/img/i10-red.jpg" class="w-75" />
        <p>- Loại xe: Hatchback<br>
          - Đời xe: 2020<br>
          - Màu xe: Trắng<br>
          - Hộp số: Số sàn<br>
          - Giá thuê xe: 600.000đ</p>
        <a href="#!">
          <div class="mask" style="background-color: rgba(137, 182, 197, 0.2)">
          <img src="view/img/xe-hover1.png" class="w-100" alt="">
          
        </div>
        
        </a>
      </div>
      <div class="bg-image hover-overlay hover-zoom hover-shadow ripple col-4">
        <img src="view/img/i10.jpg" class="w-75" />
        <p>- Loại xe: Hatchback<br>
          - Đời xe: 2020<br>
          - Màu xe: Trắng<br>
          - Hộp số: Số sàn<br>
          - Giá thuê xe: 600.000đ</p>
        <a href="#!">
          <div class="mask" style="background-color: rgba(137, 182, 197, 0.2)">
          <img src="view/img/xe-hover1.png" class="w-100" alt="">
          
        </div>
        
        </a>
      </div>
      </div>
      <div class="row wow bounceInUp" data-wow-duration="2s" data-wow-offset="10"  data-wow-iteration="1">
        <div class="bg-image hover-overlay hover-zoom hover-shadow ripple col-4">
          <img src="view/img/ford.jpg" class="w-75" />
          <p>- Loại xe: HalfTruck<br>
            - Đời xe: 2020<br>
            - Màu xe: Trắng<br>
            - Hộp số: Số sàn<br>
            - Giá thuê xe: 600.000đ</p>
          <a href="#!">
            <div class="mask" style="background-color: rgba(137, 182, 197, 0.2)">
            <img src="view/img/xe-hover1.png" class="w-100" alt="">
            
          </div>
          
          </a>
        </div>
        <div class="bg-image hover-overlay hover-zoom hover-shadow ripple col-4">
          <img src="view/img/ford-ranger-1323.jpg" class="w-75" />
          <p>- Loại xe: HalfTruck<br>
            - Đời xe: 2020<br>
            - Màu xe: Trắng<br>
            - Hộp số: Số sàn<br>
            - Giá thuê xe: 600.000đ</p>
          <a href="#!">
            <div class="mask" style="background-color: rgba(137, 182, 197, 0.2)">
            <img src="view/img/xe-hover1.png" class="w-100" alt="">
            
          </div>
          
          </a>
        </div>
        <div class="bg-image hover-overlay hover-zoom hover-shadow ripple col-4">
          <img src="view/img/camry.jpg" class="w-75" />
          <p>- Loại xe: HalfTruck<br>
            - Đời xe: 2020<br>
            - Màu xe: Trắng<br>
            - Hộp số: Số sàn<br>
            - Giá thuê xe: 600.000đ</p>
          <a href="#!">
            <div class="mask" style="background-color: rgba(137, 182, 197, 0.2)">
            <img src="view/img/xe-hover1.png" class="w-100" alt="">
            
          </div>
          
          </a>
        </div>
        </div>

        <!-- Navbar -->
<div
class="p-2 text-center bg-image"
style="
  background-image: url('view/img/dalat1.jpg');
  height: 400px;
  margin-top: 2px;
"
>
<div class="mask" style="background-color: rgba(0, 0, 0, 0.6);">
  <div class="d-flex justify-content-center align-items-center h-100">
    <div class="text-white">
      <img src="view/img/logo.png" width="200px" alt="">
      <h1 class="mb-3 text-warning">AUTOMOTIVE</h1>
      <a class="btn btn-outline-light btn-lg" href="index.php?action=thuexe" role="button"
      >THUÊ NGAY</a
      >
    </div>
  </div>
</div>
</div>
    </main>
    <!-- End your project here-->

    

   
  </body>