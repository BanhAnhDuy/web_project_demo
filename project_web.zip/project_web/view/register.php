

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng Ký</title>
    <link rel="icon" href="view/img/logo.png" type="image/x-icon" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"/>
    
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap"/>
    
    <link rel="stylesheet" href="view/css/mdb.min.css" />
    <link rel="stylesheet" href="view/css/style.css">
    
 
    
</head>
<body class="preloading container-fluid">
    <div class="load">
      <img src="view/img/load.gif" >
   </div>
  
   



<div class="login-page">
  <div class="form">
  <h1 style="background-image:url('view/img/bg-1500.jpg')" class="text-warning  m-1">ĐĂNG KÝ TÀI KHOẢN</h1>
<div style="background-image:url('view/img/meme.png')"  class=" border border-2 rounded-2 ">
    <form class="m-2 text-center" action="index.php?action=register" method="post" >
     
       <div class="row m-2">
         <div class="col-4">
         <input type="text" name="ten-user" placeholder="Nhập tên đầy đủ...">
         </div>
         <div class="col-4">
         <input type="text" name="diachi" placeholder="Nhập địa chỉ...">
         </div>
         <div class="col-4">
         <input type="email" name="email" placeholder="Nhập địa chỉ Email...">
         </div>
       </div>
       <div class="row m-2">
       <div class="col-4">
       <input type="text" name="ten-username" placeholder="Nhập Username..." required>
         </div>
         <div class="col-4">
         <input type="submit" name="dangky" value="ĐĂNG KÝ" >
         </div>
         <div class="col-4">
         <input type="password" name="pass" placeholder="Nhập Password..." required>
         </div>
       </div>
       </div>
     
       
     
    </form>
</div>




<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script type="text/javascript" src="view/js/mdb.min.js"></script>
    <script src="view/js/home.js"></script>
</body>
</html>
